package com.icbc.demo.mapper;

public interface AlphaDao {
    String select();
}
